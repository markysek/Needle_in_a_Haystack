
---
<h1><center> Needle in a Haystack - The Fraud Detection Capstone Project </center></h1>
<h2><center> Marketa Mikulkova </center></h2>

--- 

## Abstract

The ultimate goal of this project is to develop a counter-solution to account takeover attacks in payment services. The primary goal is to build a model that could identify patterns in data and spot fraudulent transactions with the highest hit-rate possible. The secondary goal is to find use of it for businesses based on their risk-aversion level:
- Send suspicious transactions to further human investigation, or
- Completely block flagged transactions

## Source of data

The lack of publicly available data on financial transactions was addressed by group TESTIMON when they introduced a simulator PaySim that creates synthetic transaction data based on a sample of real transactions from a mobile money service implemented in an unspecified African country. The synthetic dataset resembles the normal operation of transactions with injected malicious behavior. 

The data is available on Kaggle under the name Synthetic Financial Datasets For Fraud Detection. It was published by TESTIMON which is the Digital Forensics Research Group from NTNU in Gjøvik, Norway. There are various academic papers published by authors of the data simulator that help to understand what the data represent. 
https://www.kaggle.com/ntnu-testimon/paysim1#PS_20174392719_1491204439457_log.csv

## Assumptions and Considerations

### 1) Class-imbalance

Presence of fraudulent transactions tends to be rare and it is the case for given dataset as well. When trying to build the best model, I considered three different scenarios:
- oversampled train set & oversampled test set
- non-oversampled train set & non-oversampled test set
- oversampled train set & non-oversampled test set

Even though the models' performance on oversampled train and test sets was better, I decided to maintain the original proportion of fraudulent to genuine transactions for two reasons:
- the goal is to find a model that could be used in real-world conditions
- in case of unlabeled data, it wouldn't be clear which transactions to oversample

### 2)  Categorical variables with high cardinality

Two of the original features are counterparties involved in the transaction, namely, *'nameOrig'* being the unique identifier of the client where transaction originated, and the *'nameDest'* identifying the recipient of given transaction. 

My initial approach was to encode these high-cardinality variables using Weight of Evidence encoding algorithm that is based on correlation of the categorical attributes to be encoded to the target variables. The assigned/encoded numerical value is a function of number of records with the categorical value in question and how they break down between positive and negative class attribute values. Additionally, total number of records with the positive and negative class labels are also taken into account. For class imbalanced data, Weight of Evidence algorithm should work better than let's say Target or Leave-one-out encoder.

Source of inspiration: https://pkghosh.wordpress.com/2017/10/09/combating-high-cardinality-features-in-supervised-machine-learning/

I also wanted to use the *'nameOrig'* and the *'nameDest'* as a common key for identifying transactions where cash-out followed transfer, since the type of fraud present in this dataset is account takeover, but my assumption proved to be incorrect, at least for this dataset, and I couldn't link intuitively connected transactions.    

The final decision was not to use *'nameOrig'* and *'nameDest'* due to the fact that fraudsters would most probably not use the same accounts for withdrawing money from the system repetitively.  

### 3) Various models

For each of the oversampled/not-oversampled and encoded/not-encoded scenarios, 5 different classifier models or ensembles of models were used:
- logistic regression
- decision tree
- random forest
- XGBoost using decision tree as a base model
- multi-layer perceptron 

The random forest model and the XGBoost delivered the best results, hence the notebook focuses only on the two beforehand mentioned. 

# Process:

## Packages and libraries

First, the libraries to be used need to be imported.


```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn import metrics
#from imblearn.over_sampling import ADASYN 
#from category_encoders.woe import WOEEncoder
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
#from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
import xgboost as xgb
from xgboost import XGBClassifier 
#from sklearn.neural_network import MLPClassifier
from sklearn import pipeline
from sklearn import preprocessing
#from sklearn.model_selection import cross_validate
from sklearn.model_selection import cross_val_score
from sklearn.model_selection import StratifiedKFold
from sklearn.model_selection import GridSearchCV
from tempfile import mkdtemp
import pickle
import warnings
warnings.filterwarnings('ignore')
```

## Import and data cleaning

The following cell contains path to the full, 6.3 million-entries dataset. To find the best model while maintaining the run-time feasible, a 10% subset of data was used to prototype. The results were then verified on 80% and 100% of the original data and will be shown towards the end of the notebook. 


```python
# the full dataset can be downloaded from the Kaggle link mentioned in Source of data section
ps = pd.read_csv('.../paysim.csv')
ps.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>step</th>
      <th>type</th>
      <th>amount</th>
      <th>nameOrig</th>
      <th>oldbalanceOrg</th>
      <th>newbalanceOrig</th>
      <th>nameDest</th>
      <th>oldbalanceDest</th>
      <th>newbalanceDest</th>
      <th>isFraud</th>
      <th>isFlaggedFraud</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>PAYMENT</td>
      <td>9839.64</td>
      <td>C1231006815</td>
      <td>170136.0</td>
      <td>160296.36</td>
      <td>M1979787155</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>PAYMENT</td>
      <td>1864.28</td>
      <td>C1666544295</td>
      <td>21249.0</td>
      <td>19384.72</td>
      <td>M2044282225</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1</td>
      <td>TRANSFER</td>
      <td>181.00</td>
      <td>C1305486145</td>
      <td>181.0</td>
      <td>0.00</td>
      <td>C553264065</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1</td>
      <td>CASH_OUT</td>
      <td>181.00</td>
      <td>C840083671</td>
      <td>181.0</td>
      <td>0.00</td>
      <td>C38997010</td>
      <td>21182.0</td>
      <td>0.0</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1</td>
      <td>PAYMENT</td>
      <td>11668.14</td>
      <td>C2048537720</td>
      <td>41554.0</td>
      <td>29885.86</td>
      <td>M1230701703</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
# original dataset is rather large to be processed
ps.shape
```




    (6362620, 11)




```python
# class imbalance --> the percentage of fraudulent transactions in the entire dataset
print(round(sum(ps['isFraud'])/ps['isFraud'].count()*100,3),'%')
```

    0.129 %
    

<img src="attachment:Fraud%20YesNo.png" width="600">


```python
# 'stratify' flag to preserve the class imbalance 
from sklearn.model_selection import train_test_split
ps_subset, ps_rest = train_test_split(ps,test_size=0.1,random_state=38, stratify=ps['isFraud'])

# double-checking if the original ratio of fraudulent transactions stayed the same
print(round(sum(ps_subset['isFraud'])/ps_subset['isFraud'].count()*100,3),'%')
print(round(sum(ps_rest['isFraud'])/ps_rest['isFraud'].count()*100,3),'%')
```

    0.129 %
    0.129 %
    


```python
# saving the subset
ps_subset.to_csv('.../ps_subset.csv')
```


```python
# reading the 10% subset for faster processing and model prototyping 
ps_subset = pd.read_csv('.../ps_subset.csv',delimiter=',',index_col=0)
```


```python
display(ps_subset.isna().sum())
ps_subset.describe()
```


    step              0
    type              0
    amount            0
    nameOrig          0
    oldbalanceOrg     0
    newbalanceOrig    0
    nameDest          0
    oldbalanceDest    0
    newbalanceDest    0
    isFraud           0
    isFlaggedFraud    0
    dtype: int64





<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>step</th>
      <th>amount</th>
      <th>oldbalanceOrg</th>
      <th>newbalanceOrig</th>
      <th>oldbalanceDest</th>
      <th>newbalanceDest</th>
      <th>isFraud</th>
      <th>isFlaggedFraud</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>636262.000000</td>
      <td>6.362620e+05</td>
      <td>6.362620e+05</td>
      <td>6.362620e+05</td>
      <td>6.362620e+05</td>
      <td>6.362620e+05</td>
      <td>636262.000000</td>
      <td>636262.0</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>243.286706</td>
      <td>1.785372e+05</td>
      <td>8.295293e+05</td>
      <td>8.508695e+05</td>
      <td>1.101647e+06</td>
      <td>1.224799e+06</td>
      <td>0.001290</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>std</th>
      <td>142.251118</td>
      <td>5.768838e+05</td>
      <td>2.872531e+06</td>
      <td>2.908142e+06</td>
      <td>3.356923e+06</td>
      <td>3.612651e+06</td>
      <td>0.035898</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1.000000</td>
      <td>0.000000e+00</td>
      <td>0.000000e+00</td>
      <td>0.000000e+00</td>
      <td>0.000000e+00</td>
      <td>0.000000e+00</td>
      <td>0.000000</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>156.000000</td>
      <td>1.334686e+04</td>
      <td>0.000000e+00</td>
      <td>0.000000e+00</td>
      <td>0.000000e+00</td>
      <td>0.000000e+00</td>
      <td>0.000000</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>238.000000</td>
      <td>7.440781e+04</td>
      <td>1.404800e+04</td>
      <td>0.000000e+00</td>
      <td>1.332614e+05</td>
      <td>2.157892e+05</td>
      <td>0.000000</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>334.000000</td>
      <td>2.084907e+05</td>
      <td>1.072740e+05</td>
      <td>1.441518e+05</td>
      <td>9.486033e+05</td>
      <td>1.116961e+06</td>
      <td>0.000000</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>max</th>
      <td>742.000000</td>
      <td>5.560711e+07</td>
      <td>5.958504e+07</td>
      <td>4.958504e+07</td>
      <td>3.555534e+08</td>
      <td>3.553814e+08</td>
      <td>1.000000</td>
      <td>0.0</td>
    </tr>
  </tbody>
</table>
</div>



None of the values is missing. The *'isFlaggedFraud'* column has no variance and it wouldn't be very useful for deciphering patterns, therefore, it can be dropped.


```python
ps_subset = ps_subset.drop(columns=['isFlaggedFraud'])
```


```python
# setting uniform column names (Org x Orig) 
ps_subset = ps_subset.rename(columns={'oldbalanceOrg':'oldBalanceOrig', 'newbalanceOrig':'newBalanceOrig', \
                        'oldbalanceDest':'oldBalanceDest', 'newbalanceDest':'newBalanceDest'})
```

## EDA and Feature engineering 

The following section covers basic Exploratory Data Analysis (EDA) and intuitive feature engineering based on the revealed information. 


```python
# Preparing for feature creation ('correctAmount' and 'amtIsCorrect'). To avoid rounding errors, integer values are used 
# Multiplying by 100 to later divide by 100 (due to certain discrepancies in the dataset)
list_of_columns = ['oldBalanceOrig','newBalanceOrig','oldBalanceDest','newBalanceDest']
for i in list_of_columns:
    ps_subset[i] = (ps_subset[i]*100).astype(dtype='int64')
```


```python
# creating new 'correctAmount' column to be later filled with calculated amount depending on transaction type
ps_subset['correctAmount'] = 0
ps_subset['amount']=round(ps_subset['amount']).astype(dtype='int64')
```

Three sub-dataframes are created to have the *'correctAmount'* column filled with calculated values using columns that were observed as being relevant for each type of transaction. 


```python
# 'amount' and affected 'balance' columns vary depending on the type of transaction
payment_debit_df = ps_subset[(ps_subset['type']=='PAYMENT') | (ps_subset['type']=='DEBIT')].copy()
payment_debit_df['correctAmount'] = round((payment_debit_df['oldBalanceOrig']-payment_debit_df['newBalanceOrig'])/100).astype(dtype='int64')

cashout_transfer_df = ps_subset[(ps_subset['type']=='CASH_OUT') | (ps_subset['type']=='TRANSFER')].copy()
cashout_transfer_df['correctAmount'] = round((cashout_transfer_df['newBalanceDest']-cashout_transfer_df['oldBalanceDest'])/100).astype(dtype='int64')

cashin_df = ps_subset[(ps_subset['type']=='CASH_IN')].copy()
cashin_df['correctAmount'] = round((cashin_df['oldBalanceDest']-cashin_df['newBalanceDest'])/100).astype(dtype='int64')
```


```python
ps_subset_amt = pd.concat([payment_debit_df,cashout_transfer_df,cashin_df],axis=0)
```


```python
# dividing by 100 to get original 'balance' values
for i in list_of_columns:
    ps_subset_amt[i] = round((ps_subset_amt[i]/100)).astype(dtype='int64')
```

Another feature, *'amtIsCorrect'*, comparing the calculated and the reported amount, is added.   


```python
# creating second new variable 'amtIsCorrect' comapring the original reported 'amount' with amount calculated from 
    # 'new/oldBalance' columns 
ps_subset_amt['amtIsCorrect'] = np.where(ps_subset_amt['amount'] == ps_subset_amt['correctAmount'],1,0)
```

Basic overview of the new feature *'amtIsCorrect'* being able to potentially separate fraudulent from genuine transactions: 


```python
types_of_transactions = ['PAYMENT', 'DEBIT', 'CASH_OUT', 'TRANSFER', 'CASH_IN'] 
correct_amt_list = []
for i in types_of_transactions: 
    correct_amt = ps_subset_amt[(ps_subset_amt['type']==i) & (ps_subset_amt['amtIsCorrect']==1) & (ps_subset_amt['isFraud']==0)].count()/ps_subset_amt[(ps_subset_amt['type']==i)].count()
    correct_amt_list.append(correct_amt[0]*100)
    print(f' In', round(correct_amt[0]*100,2),'% of cases the amount is correct when type of transaction is',i,) 
```

     In 48.72 % of cases the amount is correct when type of transaction is PAYMENT
     In 71.48 % of cases the amount is correct when type of transaction is DEBIT
     In 90.0 % of cases the amount is correct when type of transaction is CASH_OUT
     In 89.09 % of cases the amount is correct when type of transaction is TRANSFER
     In 73.8 % of cases the amount is correct when type of transaction is CASH_IN
    


```python
types_of_transactions = ['PAYMENT', 'DEBIT', 'CASH_OUT', 'TRANSFER', 'CASH_IN'] 
correct_amt_list_fraud_yes = []
for i in types_of_transactions: 
    correct_amt_fraud_yes = ps_subset_amt[(ps_subset_amt['type']==i) & (ps_subset_amt['amtIsCorrect']==1) & (ps_subset_amt['isFraud']==1)].count()/ps_subset_amt[(ps_subset_amt['type']==i)].count()
    correct_amt_list_fraud_yes.append(correct_amt_fraud_yes[0]*100)
    print(f' In', round(correct_amt_fraud_yes[0]*100,2),'% of cases the amount is correct when type of transaction is',i,) 
```

     In 0.0 % of cases the amount is correct when type of transaction is PAYMENT
     In 0.0 % of cases the amount is correct when type of transaction is DEBIT
     In 0.18 % of cases the amount is correct when type of transaction is CASH_OUT
     In 0.0 % of cases the amount is correct when type of transaction is TRANSFER
     In 0.0 % of cases the amount is correct when type of transaction is CASH_IN
    


```python
import matplotlib.pyplot as plt
plt.figure(figsize=(8,5))
plt.tick_params(labelsize='large')
plt.scatter(types_of_transactions,correct_amt_list, label='Genuine cases',c='#8fb202')
plt.scatter(types_of_transactions,correct_amt_list_fraud_yes, label='Fraud cases',c='#00a2b3')
plt.title('Amount corresponding to difference in balances')
plt.xlabel('Type of transaction')
plt.ylabel('% of cases')
plt.legend(loc='upper left')
plt.show();
```


![png](output_42_0.png)



```python
# creating three new features to address absolute value of difference between balances and reported amount 
    # and to distinguish where is the discrepancy coming from, whether the originator or the recipient of the transaction
ps_subset_amt['diffBalanceAmtOrig']=ps_subset_amt['oldBalanceOrig']-ps_subset_amt['newBalanceOrig']-ps_subset_amt['amount']
ps_subset_amt['diffBalanceAmtDest']=ps_subset_amt['newBalanceDest']-ps_subset_amt['oldBalanceDest']-ps_subset_amt['amount']
ps_subset_amt['diffCorrectAmtAmt']=ps_subset_amt['correctAmount']-ps_subset_amt['amount']
```


```python
payment_df = ps_subset_amt[ps_subset_amt['type']=='PAYMENT'].copy()
rest_of_trans_df = ps_subset_amt[ps_subset_amt['type']!='PAYMENT'].copy()
```


```python
# payment goes through merchant and their balances don't show in this dataset by default 
payment_df['diffBalanceAmtDest'] = 0
payment_df['diffCorrectAmtAmt'] = 0
ps_subset_amt = pd.concat([payment_df,rest_of_trans_df],axis=0,sort=False)
```

The only two types of transactions where the fraud is happening are Transfer followed by Cash-out. It is logical given the type of fraud present in this dataset and the sequence the money is taken out of the mobile money platform. The number of cases is almost equal - not all the transfered money was cashed-out at once (might have been due to potential withdrawal limits). 

<img src="attachment:Fraud%20by%20transaction.png" width="600">

<img src="attachment:AvgMed%20Amt%20by%20Trans%20type.png" width="600">

Given the difference in median and average amount for genuine and fraudulent transactions, additional new features are created in hope they will help in identifying patterns:
- flag for cash-out being greater than 200,000 currency units
- flag for transfer greater than 1,000,000 currency units


```python
ps_subset_amt['COGreaterThan200000'] = 0
ps_subset_amt['TRGreaterThan1000000'] = 0
cashout_df = ps_subset_amt[ps_subset_amt['type']=='CASH_OUT'].copy()
transfer_df = ps_subset_amt[ps_subset_amt['type']=='TRANSFER'].copy()
rest_df = ps_subset_amt[(ps_subset_amt['type']=='DEBIT')|(ps_subset_amt['type']=='PAYMENT')|(ps_subset_amt['type']=='CASH_IN')].copy()
cashout_df['COGreaterThan200000'] = np.where(cashout_df['amount']>200000,1,0)
transfer_df['TRGreaterThan1000000'] = np.where(transfer_df['amount']>1000000,1,0)
ps_subset_amt = pd.concat([cashout_df,transfer_df,rest_df],axis=0,sort=False)
```

The next sub-section gives an overview of the strength of linear relationship for each pair of features. One heatmap is for fraudulent and one for genuine transactions. 


```python
corr_mat_fraud = ps_subset_amt[ps_subset_amt['isFraud']==1].corr()
corr_mat_genuine = ps_subset_amt[ps_subset_amt['isFraud']==0].corr()
corr_mat_fraud = corr_mat_fraud.corr()
corr_mat_genuine = corr_mat_genuine.corr()
```


```python
import seaborn as sns
mask_fraud = np.zeros_like(corr_mat_fraud)
mask_fraud[np.tril_indices_from(mask_fraud)] = True
fig = plt.figure(figsize=(15,12))
with sns.axes_style("white"):
    ax1 = fig.add_subplot(121)
    ax1 = sns.heatmap(corr_mat_fraud, mask=mask_fraud, square=True,center=0,cmap='RdBu_r',cbar_kws={"shrink": 0.35})
    ax1.set_title('Fraudulent transactions')
    
mask_genuine = np.zeros_like(corr_mat_genuine)
mask_genuine[np.tril_indices_from(mask_genuine)] = True
with sns.axes_style("white"):
    ax2 = fig.add_subplot(122)
    ax2 = sns.heatmap(corr_mat_genuine, mask=mask_genuine, square=True,center=0,cmap='RdBu_r',cbar_kws={"shrink": 0.35})
    ax2.set_title('Genuine transactions')
plt.tight_layout()
```


![png](output_53_0.png)


Different level of correlations for each subset of transactions (fraudulent/non-fraudulent) is promising to give the models guidance when deciphering well-hidden patterns.  

## Introducing dummy variables

In order to be able to work with categorical data, the majority of models needs to be fed with a numerical representation of such data. In this case, one-hot encoding will be used to replace the *'type'* of transaction. 


```python
# moving 'isFraud' to the front
cols = list(ps_subset_amt)
cols.insert(0, cols.pop(cols.index('isFraud')))
# using loc to assign new order
ps_subset_amt = ps_subset_amt.loc[:, cols]
```


```python
type_dummies = pd.get_dummies(ps_subset_amt['type'])[['CASH_OUT','TRANSFER','DEBIT','PAYMENT','CASH_IN']] 
ps_subset_amt = pd.concat([ps_subset_amt, type_dummies], axis = 1)
ps_subset_amt.drop(columns=['type'],inplace=True)
```

## Train / test split

The dataset will be split in two parts - 75% train set to be used for fitting the model, and a 25% test set to be used for predictions and evaluating precision of the predicted results when compared to the true values. For the purpose of finding the best hyperparameters for each model, cross-validation results will be used. 


```python
from sklearn.model_selection import train_test_split

# train 75%, test 25% 
train_data, test_data = train_test_split(ps_subset_amt,test_size=0.25,random_state=38,stratify=ps_subset_amt['isFraud'])
```


```python
# dropping the original index from full 6.3 million dataset  
train_data.reset_index(drop=True,inplace=True)
test_data.reset_index(drop=True,inplace=True)
train_data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>isFraud</th>
      <th>step</th>
      <th>amount</th>
      <th>nameOrig</th>
      <th>oldBalanceOrig</th>
      <th>newBalanceOrig</th>
      <th>nameDest</th>
      <th>oldBalanceDest</th>
      <th>newBalanceDest</th>
      <th>correctAmount</th>
      <th>...</th>
      <th>diffBalanceAmtOrig</th>
      <th>diffBalanceAmtDest</th>
      <th>diffCorrectAmtAmt</th>
      <th>COGreaterThan200000</th>
      <th>TRGreaterThan1000000</th>
      <th>CASH_OUT</th>
      <th>TRANSFER</th>
      <th>DEBIT</th>
      <th>PAYMENT</th>
      <th>CASH_IN</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>372</td>
      <td>8737</td>
      <td>C357424501</td>
      <td>0</td>
      <td>0</td>
      <td>C227193796</td>
      <td>1093596</td>
      <td>1102332</td>
      <td>8737</td>
      <td>...</td>
      <td>-8737</td>
      <td>-1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0</td>
      <td>571</td>
      <td>251034</td>
      <td>C418941830</td>
      <td>250145</td>
      <td>0</td>
      <td>C1891153708</td>
      <td>0</td>
      <td>251034</td>
      <td>251034</td>
      <td>...</td>
      <td>-889</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0</td>
      <td>259</td>
      <td>194237</td>
      <td>C272225225</td>
      <td>0</td>
      <td>0</td>
      <td>C1050406642</td>
      <td>14181036</td>
      <td>14375274</td>
      <td>194237</td>
      <td>...</td>
      <td>-194237</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0</td>
      <td>348</td>
      <td>230752</td>
      <td>C2136008756</td>
      <td>0</td>
      <td>0</td>
      <td>C82886026</td>
      <td>380875</td>
      <td>611627</td>
      <td>230752</td>
      <td>...</td>
      <td>-230752</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0</td>
      <td>164</td>
      <td>56383</td>
      <td>C298578846</td>
      <td>21356</td>
      <td>77739</td>
      <td>C1751918611</td>
      <td>15184</td>
      <td>0</td>
      <td>15184</td>
      <td>...</td>
      <td>-112766</td>
      <td>-71567</td>
      <td>-41199</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 21 columns</p>
</div>




```python
# separating features from labels
x_train = train_data.iloc[:,1:]
y_train = train_data.iloc[:,0]
x_test = test_data.iloc[:,1:]
y_test = test_data.iloc[:,0]
```

## Working with only numerical data from now on

To demonstrate the added value of engineered features, a Base case scenario will be evaluated and then compared to a scenario with 7 additional independent variables. For neither one of the cases, the identifiers of involved counterparties will be used as mentioned in considerations early on.  


```python
# base case
x_train_num_BC = x_train.drop(columns=['nameOrig','nameDest','correctAmount','amtIsCorrect','diffBalanceAmtOrig',\
                                       'diffBalanceAmtDest','diffCorrectAmtAmt','COGreaterThan200000','TRGreaterThan1000000'])
x_test_num_BC = x_test.drop(columns=['nameOrig','nameDest','correctAmount','amtIsCorrect','diffBalanceAmtOrig',\
                                     'diffBalanceAmtDest','diffCorrectAmtAmt','COGreaterThan200000','TRGreaterThan1000000'])
# engineered features
x_train_num = x_train.drop(columns=['nameOrig','nameDest'])
x_test_num = x_test.drop(columns=['nameOrig','nameDest'])
```


```python
# storing columns names so they could be later assigned back to respective columns after getting lost during scaling process 
cols_x_num_BC = list(x_train_num_BC.columns)
cols_x_num = list(x_train_num.columns)
cols_x = list(x_train.columns)
```


```python
# assigning subsets different names to be consistent with names used early on in the process  
x_train_os_num_BC, y_train_os_num_BC = x_train_num_BC, y_train
x_test_os_num_BC, y_test_os_num_BC = x_test_num_BC, y_test
x_train_os_num, y_train_os_num = x_train_num, y_train
x_test_os_num, y_test_os_num = x_test_num, y_test
```


```python
# scaling and transforming data so the model doesn't act in favor of features with greater units and, therefore, 
    # potential higher variance
from sklearn.preprocessing import StandardScaler

scaler_num = StandardScaler()
scaler_num.fit(x_train_os_num)
x_train_os_num = scaler_num.transform(x_train_os_num)
x_test_os_num = scaler_num.transform(x_test_os_num)

scaler_num_BC = StandardScaler()
scaler_num_BC.fit(x_train_os_num_BC)
x_train_os_num_BC = scaler_num_BC.transform(x_train_os_num_BC)
x_test_os_num_BC = scaler_num_BC.transform(x_test_os_num_BC)
```


```python
# renaming columns to make sure they appear properly in feature importance graphs
x_train_os_num = pd.DataFrame(x_train_os_num,columns=cols_x_num)
x_test_os_num = pd.DataFrame(x_test_os_num,columns=cols_x_num)
x_train_os_num_BC = pd.DataFrame(x_train_os_num_BC,columns=cols_x_num_BC)
x_test_os_num_BC = pd.DataFrame(x_test_os_num_BC,columns=cols_x_num_BC)

y_train_os_num = pd.DataFrame(y_train_os_num,columns=['isFraud'])
y_test_os_num = pd.DataFrame(y_test_os_num,columns=['isFraud'])
y_train_os_num_BC = pd.DataFrame(y_train_os_num_BC,columns=['isFraud'])
y_test_os_num_BC = pd.DataFrame(y_test_os_num_BC,columns=['isFraud'])
```

## Keeping track of different model's metrics

90 different scenarios covering cases with oversampled and non-oversampled datasets & encoded and non-encoded categorical variables were considered. The table below shows and overview of the key metrics stored for each combination of used model and set of data. The *final_results_table* is storing results from the best two models on the go, comparing the performance for the Base case scenario, using only original set of features (excluding *nameOrig* and *nameDest*), and the 'engineered' scenario with additional 7 features.  


```python
final_results_table = pd.DataFrame(columns=['Model','Train/Test','DataSize','OverSamp_Train','OverSamp_Test','EncodedCP',\
                                            'Accuracy','Precision','Recall','F1Score','AUPRC','Features'])
results_table = pd.read_csv('.../results_table.csv',sep=';',index_col=0,\
                           dtype = {'Model': str,'Train/Test/Val': str,'DataSize': int,'OverSamp_Train': int,\
                                    'OverSamp_Test': int,'EncodedCP': int,'Accuracy': float,'Accuracy': float,\
                                   'Recall': float,'F1Score': float,'AUPRC': float,'Features': str})
display(results_table.shape)
results_table.head()
```


    (90, 12)





<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Model</th>
      <th>Train/Test</th>
      <th>DataSize</th>
      <th>OverSamp_Train</th>
      <th>OverSamp_Test</th>
      <th>EncodedCP</th>
      <th>Accuracy</th>
      <th>Precision</th>
      <th>Recall</th>
      <th>F1Score</th>
      <th>AUPRC</th>
      <th>Features</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>logreg_model_num_BC</td>
      <td>train</td>
      <td>595663</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>95.59</td>
      <td>89.96</td>
      <td>87.72</td>
      <td>88.82</td>
      <td>80.87</td>
      <td>Index(['step', 'amount', 'oldBalanceOrig', 'ne...</td>
    </tr>
    <tr>
      <th>1</th>
      <td>logreg_model_num_BC</td>
      <td>test</td>
      <td>79436</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>95.77</td>
      <td>89.76</td>
      <td>88.99</td>
      <td>89.37</td>
      <td>81.90</td>
      <td>Index(['step', 'amount', 'oldBalanceOrig', 'ne...</td>
    </tr>
    <tr>
      <th>2</th>
      <td>logreg_model_enc_BC</td>
      <td>train</td>
      <td>595663</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>95.73</td>
      <td>89.82</td>
      <td>88.71</td>
      <td>89.26</td>
      <td>81.69</td>
      <td>Index(['step', 'amount', 'nameOrig', 'oldBalan...</td>
    </tr>
    <tr>
      <th>3</th>
      <td>logreg_model_enc_BC</td>
      <td>test</td>
      <td>79436</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>95.45</td>
      <td>89.95</td>
      <td>86.96</td>
      <td>88.43</td>
      <td>80.17</td>
      <td>Index(['step', 'amount', 'nameOrig', 'oldBalan...</td>
    </tr>
    <tr>
      <th>4</th>
      <td>DT_model_num_BC</td>
      <td>train</td>
      <td>595663</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>99.84</td>
      <td>99.43</td>
      <td>99.76</td>
      <td>99.59</td>
      <td>99.30</td>
      <td>Index(['step', 'amount', 'oldBalanceOrig', 'ne...</td>
    </tr>
  </tbody>
</table>
</div>



## Selecting the best model

When picking the best model, filter on non-oversampled train and test set was used so the model can perform well in real-world conditions. The F1 Score metric, balancing the Precision and Recall, was selected as the most important for this project due to the present class-imbalance and the fraud detection use case. Solution able to catch as many fraud cases as possible (maximizing Recall), while introducing ideally no additional friction on the payment services customer journey (maximizing Precision) is sought after.   

Based on the assumptions given to encoding involved counterparties in each transaction, only models denoted with *_num* were taken into consideration. The top two models are XGBoost model (line 49) and Random Forest model (line 45).  

Earlier during the project, the data was split to train, test and validation set but I didn't end up using the validation test for tuning the hyperparameters, instead, I used cross-validation. The results stored in the results table are on train and test data equal to 75% and 15% of the used subset (10% from the 6.3 millions of transactions), while the remaining 10% validation set wasn't used. The two models that were picked as the best, are then trained on a 75% train set and predictions are done on 25%. The results in the table below are all on the same train/test/validation split, therefore consistent for comparison.  


```python
results_table[(results_table['Train/Test']=='test') & (results_table['OverSamp_Train']==0) & \
              (results_table['OverSamp_Test']==0)].sort_values(['F1Score','AUPRC'],ascending=False).head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Model</th>
      <th>Train/Test</th>
      <th>DataSize</th>
      <th>OverSamp_Train</th>
      <th>OverSamp_Test</th>
      <th>EncodedCP</th>
      <th>Accuracy</th>
      <th>Precision</th>
      <th>Recall</th>
      <th>F1Score</th>
      <th>AUPRC</th>
      <th>Features</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>47</th>
      <td>RF_model_enc</td>
      <td>test</td>
      <td>63627</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>100.0</td>
      <td>98.80</td>
      <td>100.0</td>
      <td>99.39</td>
      <td>98.80</td>
      <td>Index(['step', 'amount', 'nameOrig', 'oldBalan...</td>
    </tr>
    <tr>
      <th>49</th>
      <td>XGB_model_num</td>
      <td>test</td>
      <td>63627</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>100.0</td>
      <td>98.80</td>
      <td>100.0</td>
      <td>99.39</td>
      <td>98.80</td>
      <td>Index(['step', 'amount', 'oldBalanceOrig', 'ne...</td>
    </tr>
    <tr>
      <th>51</th>
      <td>XGB_model_enc</td>
      <td>test</td>
      <td>63627</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>100.0</td>
      <td>98.80</td>
      <td>100.0</td>
      <td>99.39</td>
      <td>98.80</td>
      <td>Index(['step', 'amount', 'nameOrig', 'oldBalan...</td>
    </tr>
    <tr>
      <th>45</th>
      <td>RF_model_num</td>
      <td>test</td>
      <td>63627</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>100.0</td>
      <td>97.62</td>
      <td>100.0</td>
      <td>98.80</td>
      <td>97.62</td>
      <td>Index(['step', 'amount', 'oldBalanceOrig', 'ne...</td>
    </tr>
    <tr>
      <th>41</th>
      <td>DT_model_num</td>
      <td>test</td>
      <td>63627</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>100.0</td>
      <td>96.47</td>
      <td>100.0</td>
      <td>98.20</td>
      <td>96.48</td>
      <td>Index(['step', 'amount', 'oldBalanceOrig', 'ne...</td>
    </tr>
  </tbody>
</table>
</div>



## Random Forest Models 

Results for the Base case scenario:


```python
from sklearn.ensemble import RandomForestClassifier
RF_model_os_num_BC = RandomForestClassifier()
RF_model_os_num_BC.fit(x_train_os_num_BC, y_train_os_num_BC)

decision_tree_train_accuracy = []
decision_tree_train_recall = []
decision_tree_train_precision = []
decision_tree_train_AUPRC = []
decision_tree_train_F1 = []
decision_tree_test_accuracy = []
decision_tree_test_recall = []
decision_tree_test_precision = []
decision_tree_test_F1 = []
decision_tree_test_AUPRC = []

for sub_tree in RF_model_os_num_BC.estimators_:
    decision_tree_train_accuracy.append(sub_tree.score(x_train_os_num_BC,y_train_os_num_BC)*100)
    decision_tree_train_recall.append(metrics.recall_score(y_train_os_num_BC,sub_tree.predict(x_train_os_num_BC))*100)
    decision_tree_train_precision.append(metrics.precision_score(y_train_os_num_BC,sub_tree.predict(x_train_os_num_BC))*100)
    decision_tree_train_AUPRC.append(metrics.average_precision_score(y_train_os_num_BC,sub_tree.predict(x_train_os_num_BC))*100)
    decision_tree_train_F1.append(metrics.f1_score(y_train_os_num_BC,sub_tree.predict(x_train_os_num_BC))*100)
    
    decision_tree_test_accuracy.append(sub_tree.score(x_test_os_num_BC,y_test_os_num_BC)*100)
    decision_tree_test_recall.append(metrics.recall_score(y_test_os_num_BC,sub_tree.predict(x_test_os_num_BC))*100)
    decision_tree_test_precision.append(metrics.precision_score(y_test_os_num_BC,sub_tree.predict(x_test_os_num_BC))*100)
    decision_tree_test_AUPRC.append(metrics.average_precision_score(y_test_os_num_BC,sub_tree.predict(x_test_os_num_BC))*100)
    decision_tree_test_F1.append(metrics.f1_score(y_test_os_num_BC,sub_tree.predict(x_test_os_num_BC))*100)

train_accuracy = round(max(decision_tree_train_accuracy),2)
train_precision = round(max(decision_tree_train_precision),2)
train_recall = round(max(decision_tree_train_recall),2)
train_F1_score = round(max(decision_tree_train_F1),2)
train_AUPRC = round(max(decision_tree_train_AUPRC),2)

test_accuracy = round(max(decision_tree_test_accuracy),2)
test_precision = round(max(decision_tree_test_precision),2)
test_recall = round(max(decision_tree_test_recall),2)
test_F1_score = round(max(decision_tree_test_F1),2)
test_AUPRC = round(max(decision_tree_test_AUPRC),2)
# fill a list with train/test/validation results
results_train = ['RF_model_num_BC','train',x_train_os_num_BC.shape[0],0,0,0,train_accuracy,train_precision,train_recall,\
                 train_F1_score,train_AUPRC,x_train_os_num_BC.columns]
results_test = ['RF_model_num_BC','test',x_test_os_num_BC.shape[0],0,0,0,test_accuracy,test_precision,test_recall,\
                test_F1_score,test_AUPRC,x_test_os_num_BC.columns]
# turn list into a np.array, then to a DF
results_train_df = pd.DataFrame(np.array(results_train).reshape(1,-1),columns=final_results_table.columns)
results_test_df = pd.DataFrame(np.array(results_test).reshape(1,-1),columns=final_results_table.columns)
# concatenate to final_results_table
final_results_table = pd.concat([final_results_table,results_train_df,results_test_df],axis=0,ignore_index=True)
# display newly added rows of results_table
display(final_results_table.tail(2))
print(f'{metrics.confusion_matrix(y_test_os_num_BC,RF_model_os_num_BC.predict(x_test_os_num_BC))}')
```


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Model</th>
      <th>Train/Test</th>
      <th>DataSize</th>
      <th>OverSamp_Train</th>
      <th>OverSamp_Test</th>
      <th>EncodedCP</th>
      <th>Accuracy</th>
      <th>Precision</th>
      <th>Recall</th>
      <th>F1Score</th>
      <th>AUPRC</th>
      <th>Features</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>RF_model_num_BC</td>
      <td>train</td>
      <td>477196</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>99.98</td>
      <td>94.69</td>
      <td>92.69</td>
      <td>93.68</td>
      <td>87.79</td>
      <td>Index(['step', 'amount', 'oldBalanceOrig', 'ne...</td>
    </tr>
    <tr>
      <th>1</th>
      <td>RF_model_num_BC</td>
      <td>test</td>
      <td>159066</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>99.94</td>
      <td>80.42</td>
      <td>75.61</td>
      <td>77.39</td>
      <td>59.97</td>
      <td>Index(['step', 'amount', 'oldBalanceOrig', 'ne...</td>
    </tr>
  </tbody>
</table>
</div>


    [[158858      3]
     [    58    147]]
    

The confusion matrix shows that while 158,858 cases were correctly classified as non-fraudulent and 147 correctly classified as fraudulent, 3 cases got misclassified as being fraudulent when they weren't and 58 fraud cases were missed. These results show room for great improvement.  


```python
# defining a path to local directory where the model should be saved 
pkl_filename = '.../RF_num_BC_10pc_diffCorrAmtAmt_CO_TR_no_validation.pkl'
```


```python
import pickle
# Save the model to defined folder
pickle.dump(RF_model_os_num_BC, open(pkl_filename, 'wb'))
```


```python
# Load the model from file without the need to fit it to training data again
RF_model_os_num_BC = pickle.load(open(pkl_filename, 'rb'))
metrics.confusion_matrix(y_test_os_num_BC,RF_model_os_num_BC.predict(x_test_os_num_BC))
```




    array([[158858,      3],
           [    58,    147]], dtype=int64)




```python
from sklearn.ensemble import RandomForestClassifier
RF_model_os_num = RandomForestClassifier()
RF_model_os_num.fit(x_train_os_num, y_train_os_num)

decision_tree_train_accuracy = []
decision_tree_train_recall = []
decision_tree_train_precision = []
decision_tree_train_AUPRC = []
decision_tree_train_F1 = []
decision_tree_test_accuracy = []
decision_tree_test_recall = []
decision_tree_test_precision = []
decision_tree_test_F1 = []
decision_tree_test_AUPRC = []

for sub_tree in RF_model_os_num.estimators_:
    decision_tree_train_accuracy.append(sub_tree.score(x_train_os_num,y_train_os_num)*100)
    decision_tree_train_recall.append(metrics.recall_score(y_train_os_num,sub_tree.predict(x_train_os_num))*100)
    decision_tree_train_precision.append(metrics.precision_score(y_train_os_num,sub_tree.predict(x_train_os_num))*100)
    decision_tree_train_AUPRC.append(metrics.average_precision_score(y_train_os_num,sub_tree.predict(x_train_os_num))*100)
    decision_tree_train_F1.append(metrics.f1_score(y_train_os_num,sub_tree.predict(x_train_os_num))*100)
    
    decision_tree_test_accuracy.append(sub_tree.score(x_test_os_num,y_test_os_num)*100)
    decision_tree_test_recall.append(metrics.recall_score(y_test_os_num,sub_tree.predict(x_test_os_num))*100)
    decision_tree_test_precision.append(metrics.precision_score(y_test_os_num,sub_tree.predict(x_test_os_num))*100)
    decision_tree_test_AUPRC.append(metrics.average_precision_score(y_test_os_num,sub_tree.predict(x_test_os_num))*100)
    decision_tree_test_F1.append(metrics.f1_score(y_test_os_num,sub_tree.predict(x_test_os_num))*100)

train_accuracy = round(max(decision_tree_train_accuracy),2)
train_precision = round(max(decision_tree_train_precision),2)
train_recall = round(max(decision_tree_train_recall),2)
train_F1_score = round(max(decision_tree_train_F1),2)
train_AUPRC = round(max(decision_tree_train_AUPRC),2)

test_accuracy = round(max(decision_tree_test_accuracy),2)
test_precision = round(max(decision_tree_test_precision),2)
test_recall = round(max(decision_tree_test_recall),2)
test_F1_score = round(max(decision_tree_test_F1),2)
test_AUPRC = round(max(decision_tree_test_AUPRC),2)
# fill a list with train/test results
results_train = ['RF_model_num','train',x_train_os_num.shape[0],0,0,0,train_accuracy,train_precision,train_recall,\
                 train_F1_score,train_AUPRC,x_train_os_num.columns]
results_test = ['RF_model_num','test',x_test_os_num.shape[0],0,0,0,test_accuracy,test_precision,test_recall,test_F1_score,\
                test_AUPRC,x_test_os_num.columns]
# turn list into a np.array, then to a DF
results_train_df = pd.DataFrame(np.array(results_train).reshape(1,-1),columns=final_results_table.columns)
results_test_df = pd.DataFrame(np.array(results_test).reshape(1,-1),columns=final_results_table.columns)
# concatenate to results_table
final_results_table = pd.concat([final_results_table,results_train_df,results_test_df],axis=0,ignore_index=True)
# display newly added rows of results_table
display(final_results_table.tail(2))
print(f'{metrics.confusion_matrix(y_test_os_num,RF_model_os_num.predict(x_test_os_num))}')
```


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Model</th>
      <th>Train/Test</th>
      <th>DataSize</th>
      <th>OverSamp_Train</th>
      <th>OverSamp_Test</th>
      <th>EncodedCP</th>
      <th>Accuracy</th>
      <th>Precision</th>
      <th>Recall</th>
      <th>F1Score</th>
      <th>AUPRC</th>
      <th>Features</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2</th>
      <td>RF_model_num</td>
      <td>train</td>
      <td>477196</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>100</td>
      <td>99.51</td>
      <td>99.84</td>
      <td>99.68</td>
      <td>99.35</td>
      <td>Index(['step', 'amount', 'oldBalanceOrig', 'ne...</td>
    </tr>
    <tr>
      <th>3</th>
      <td>RF_model_num</td>
      <td>test</td>
      <td>159066</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>100</td>
      <td>99.02</td>
      <td>100</td>
      <td>99.03</td>
      <td>98.09</td>
      <td>Index(['step', 'amount', 'oldBalanceOrig', 'ne...</td>
    </tr>
  </tbody>
</table>
</div>


    [[158859      2]
     [     0    205]]
    

The performance of Random Forest model using additional features has significantly improved compared to the Base case.


```python
# defining a path to local directory where the model should be saved 
pkl_filename = '.../RF_num_10pc_5features_diffCorrAmtAmt_CO_TR_no_validation.pkl'
```


```python
import pickle
# Save the model to local folder
pickle.dump(RF_model_os_num, open(pkl_filename, 'wb'))
```


```python
# Load the model from file
RF_model_os_num = pickle.load(open(pkl_filename, 'rb'))
metrics.confusion_matrix(y_test_os_num,RF_model_os_num.predict(x_test_os_num))
```




    array([[158859,      2],
           [     0,    205]], dtype=int64)



The two graphs below show how many times was each feature used for decision whether the case was or was not genuine.  


```python
plt.rcParams['figure.figsize'] = [8, 5]
(pd.Series(RF_model_os_num_BC.feature_importances_,index=cols_x_num_BC)
    .nlargest(25)
    .plot(kind='barh',color='#00a2b3',title='Feature Importances - Random Forest - Base Case'))
plt.show();
plt.rcParams['figure.figsize'] = [8, 5]
(pd.Series(RF_model_os_num.feature_importances_,index=cols_x_num)
    .nlargest(25)
    .plot(kind='barh',color='#8fb202',title='Feature Importances - Random Forest - Engineered Features'))
plt.show();
```


![png](output_90_0.png)



![png](output_90_1.png)


## XGBoost

Boosting is a sequential technique which works on the principle of an ensemble of base models (decision trees used in this case). It combines a set of weak learners and delivers improved prediction accuracy due to giving higher weight to misclassified cases and lower weight to correctly classified entries. A weak learner is a model being slightly better than random guessing, e.g. a decision tree whose predictions are slightly better than 50%.

Below are results of XGBoost model using Base case scenario.


```python
# pip install xgboost
import xgboost as xgb
from xgboost import XGBClassifier 
XGB_model_os_num_BC = XGBClassifier(n_estimators=100)
XGB_model_os_num_BC.fit(x_train_os_num_BC,y_train_os_num_BC)

train_accuracy = round(XGB_model_os_num_BC.score(x_train_os_num_BC,y_train_os_num_BC)*100,2)
train_precision = round(metrics.precision_score(y_train_os_num_BC,XGB_model_os_num_BC.predict(x_train_os_num_BC))*100,2)
train_recall = round(metrics.recall_score(y_train_os_num_BC,XGB_model_os_num_BC.predict(x_train_os_num_BC))*100,2)
train_F1_score = round(metrics.f1_score(y_train_os_num_BC,XGB_model_os_num_BC.predict(x_train_os_num_BC))*100,2)
train_AUPRC = round(metrics.average_precision_score(y_train_os_num_BC,XGB_model_os_num_BC.predict(x_train_os_num_BC))*100,2)

test_accuracy = round(XGB_model_os_num_BC.score(x_test_os_num_BC,y_test_os_num_BC)*100,2)
test_precision = round(metrics.precision_score(y_test_os_num_BC,XGB_model_os_num_BC.predict(x_test_os_num_BC))*100,2)
test_recall = round(metrics.recall_score(y_test_os_num_BC,XGB_model_os_num_BC.predict(x_test_os_num_BC))*100,2)
test_F1_score = round(metrics.f1_score(y_test_os_num_BC,XGB_model_os_num_BC.predict(x_test_os_num_BC))*100,2)
test_AUPRC = round(metrics.average_precision_score(y_test_os_num_BC,XGB_model_os_num_BC.predict(x_test_os_num_BC))*100,2)

# fill a list with train/test/validation results
results_train = ['XGB_model_num_BC','train',x_train_os_num_BC.shape[0],0,0,0,train_accuracy,train_precision,train_recall,\
                 train_F1_score,train_AUPRC,x_train_os_num_BC.columns]
results_test = ['XGB_model_num_BC','test',x_test_os_num_BC.shape[0],0,0,0,test_accuracy,test_precision,test_recall,\
                test_F1_score,test_AUPRC,x_test_os_num_BC.columns]
# turn list into a np.array, then to a DF
results_train_df = pd.DataFrame(np.array(results_train).reshape(1,-1),columns=final_results_table.columns)
results_test_df = pd.DataFrame(np.array(results_test).reshape(1,-1),columns=final_results_table.columns)
# concatenate to results_table
final_results_table = pd.concat([final_results_table,results_train_df,results_test_df],axis=0,ignore_index=True)
# display newly added rows of results_table
display(final_results_table.tail(2))
print(f'{metrics.confusion_matrix(y_test_os_num_BC,XGB_model_os_num_BC.predict(x_test_os_num_BC))}')
```


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Model</th>
      <th>Train/Test</th>
      <th>DataSize</th>
      <th>OverSamp_Train</th>
      <th>OverSamp_Test</th>
      <th>EncodedCP</th>
      <th>Accuracy</th>
      <th>Precision</th>
      <th>Recall</th>
      <th>F1Score</th>
      <th>AUPRC</th>
      <th>Features</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>4</th>
      <td>XGB_model_num_BC</td>
      <td>train</td>
      <td>477196</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>99.96</td>
      <td>99.55</td>
      <td>71.92</td>
      <td>83.51</td>
      <td>71.63</td>
      <td>Index(['step', 'amount', 'oldBalanceOrig', 'ne...</td>
    </tr>
    <tr>
      <th>5</th>
      <td>XGB_model_num_BC</td>
      <td>test</td>
      <td>159066</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>99.96</td>
      <td>97.24</td>
      <td>68.78</td>
      <td>80.57</td>
      <td>66.92</td>
      <td>Index(['step', 'amount', 'oldBalanceOrig', 'ne...</td>
    </tr>
  </tbody>
</table>
</div>


    [[158857      4]
     [    64    141]]
    


```python
pkl_filename = '.../XGB_num_BC_10pc_diffCorrAmtAmt_CO_TR_no_validation.pkl'
```


```python
import pickle
# Save the model to local folder
pickle.dump(XGB_model_os_num_BC, open(pkl_filename, 'wb'))
```


```python
# Load the model from file later
XGB_model_os_num_BC = pickle.load(open(pkl_filename, 'rb'))
metrics.confusion_matrix(y_test_os_num_BC,XGB_model_os_num_BC.predict(x_test_os_num_BC))
```




    array([[158857,      4],
           [    64,    141]], dtype=int64)




```python
# scenario with additional 7 features
import xgboost as xgb
from xgboost import XGBClassifier 
XGB_model_os_num = XGBClassifier(n_estimators=100)
XGB_model_os_num.fit(x_train_os_num,y_train_os_num)

train_accuracy = round(XGB_model_os_num.score(x_train_os_num,y_train_os_num)*100,2)
train_precision = round(metrics.precision_score(y_train_os_num,XGB_model_os_num.predict(x_train_os_num))*100,2)
train_recall = round(metrics.recall_score(y_train_os_num,XGB_model_os_num.predict(x_train_os_num))*100,2)
train_F1_score = round(metrics.f1_score(y_train_os_num,XGB_model_os_num.predict(x_train_os_num))*100,2)
train_AUPRC = round(metrics.average_precision_score(y_train_os_num,XGB_model_os_num.predict(x_train_os_num))*100,2)

test_accuracy = round(XGB_model_os_num.score(x_test_os_num,y_test_os_num)*100,2)
test_precision = round(metrics.precision_score(y_test_os_num,XGB_model_os_num.predict(x_test_os_num))*100,2)
test_recall = round(metrics.recall_score(y_test_os_num,XGB_model_os_num.predict(x_test_os_num))*100,2)
test_F1_score = round(metrics.f1_score(y_test_os_num,XGB_model_os_num.predict(x_test_os_num))*100,2)
test_AUPRC = round(metrics.average_precision_score(y_test_os_num,XGB_model_os_num.predict(x_test_os_num))*100,2)

# fill a list with train/test results
results_train = ['XGB_model_num','train',x_train_os_num.shape[0],0,0,0,train_accuracy,train_precision,train_recall,\
                 train_F1_score,train_AUPRC,x_train_os_num.columns]
results_test = ['XGB_model_num','test',x_test_os_num.shape[0],0,0,0,test_accuracy,test_precision,test_recall,test_F1_score,\
                test_AUPRC,x_test_os_num.columns]
# turn list into a np.array, then to a DF
results_train_df = pd.DataFrame(np.array(results_train).reshape(1,-1),columns=final_results_table.columns)
results_test_df = pd.DataFrame(np.array(results_test).reshape(1,-1),columns=final_results_table.columns)
# concatenate to results_table
final_results_table = pd.concat([final_results_table,results_train_df,results_test_df],axis=0,ignore_index=True)
# display newly added rows of results_table
display(final_results_table.tail(2))
print(f'{metrics.confusion_matrix(y_test_os_num,XGB_model_os_num.predict(x_test_os_num))}')
```


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Model</th>
      <th>Train/Test</th>
      <th>DataSize</th>
      <th>OverSamp_Train</th>
      <th>OverSamp_Test</th>
      <th>EncodedCP</th>
      <th>Accuracy</th>
      <th>Precision</th>
      <th>Recall</th>
      <th>F1Score</th>
      <th>AUPRC</th>
      <th>Features</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>6</th>
      <td>XGB_model_num</td>
      <td>train</td>
      <td>477196</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>100</td>
      <td>99.67</td>
      <td>99.51</td>
      <td>99.59</td>
      <td>99.19</td>
      <td>Index(['step', 'amount', 'oldBalanceOrig', 'ne...</td>
    </tr>
    <tr>
      <th>7</th>
      <td>XGB_model_num</td>
      <td>test</td>
      <td>159066</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>100</td>
      <td>99.03</td>
      <td>100</td>
      <td>99.51</td>
      <td>99.03</td>
      <td>Index(['step', 'amount', 'oldBalanceOrig', 'ne...</td>
    </tr>
  </tbody>
</table>
</div>


    [[158859      2]
     [     0    205]]
    

The type of misclassification is rather positive in this case when the model is more conservative and classified two cases as being fraudulent when they are not. The implication in real life would be probably blocking such transactions. It is assumed that payment service provider would like to avoid such misclassifications not to create unnecessary friction during customer's shopping experience. 


```python
pkl_filename = '.../XGB_num_10pc_5features_diffCorrAmtAmt_CO_TR_no_validation.pkl'
```


```python
import pickle
# Save the model to my folder
pickle.dump(XGB_model_os_num, open(pkl_filename, 'wb'))
```


```python
# Load the model from file later
XGB_model_os_num = pickle.load(open(pkl_filename, 'rb'))
metrics.confusion_matrix(y_test_os_num,XGB_model_os_num.predict(x_test_os_num))
```




    array([[158859,      2],
           [     0,    205]], dtype=int64)




```python
# results on 10% of the data
fin = final_results_table.loc[[5,7],:]
fin = fin.drop(columns=['Features','Train/Test','DataSize','OverSamp_Train','OverSamp_Test','EncodedCP'])
display(fin)
```


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Model</th>
      <th>Accuracy</th>
      <th>Precision</th>
      <th>Recall</th>
      <th>F1Score</th>
      <th>AUPRC</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>5</th>
      <td>XGB_model_num_BC</td>
      <td>99.96</td>
      <td>97.24</td>
      <td>68.78</td>
      <td>80.57</td>
      <td>66.92</td>
    </tr>
    <tr>
      <th>7</th>
      <td>XGB_model_num</td>
      <td>100.00</td>
      <td>99.03</td>
      <td>100.00</td>
      <td>99.51</td>
      <td>99.03</td>
    </tr>
  </tbody>
</table>
</div>


For comparison, the below table shows the results for the initial train 75%/test 15%/validation 10% split before hyperparameters' tuning for a 10%, 80% subset of data and for the full 100% of data. Also, the respective confusion matrices are displayed. It wasn't feasible to run the tests again on the 75:25 split and on the 100% of the data due to computational capacity.  

![final_results_table_XGB_10_80_100.png](attachment:final_results_table_XGB_10_80_100.png)

![Confusion%20matrix_10_80_100pct.png](attachment:Confusion%20matrix_10_80_100pct.png)


```python
# visualizing the importance of features using bar graph
plt.rcParams['figure.figsize'] = [8, 5]
xgb.plot_importance(XGB_model_os_num_BC,grid=False, height=0.8,color='#00a2b3',title='Feature Importances - XGBoost - Base Case')
plt.show();
plt.rcParams['figure.figsize'] = [8, 5]
xgb.plot_importance(XGB_model_os_num,grid=False, height=0.8,color='#8fb202',title='Feature Importances - XGBoost - Engineered features')
plt.show();
```


![png](output_106_0.png)



![png](output_106_1.png)


The Base case feature importance graph shows that the model pays higher attention to the balances of originator of the transaction than to balances of the recipient. The assumption that distinguishing the sources of discrepancies between the *difference in balances* and the *reported amount* could have an impact on the decisions of the model has proven to be correct.  


```python
fraudulent = ps_subset_amt[ps_subset_amt['isFraud']==1]
genuine = ps_subset_amt[ps_subset_amt['isFraud']==0]
```


```python
from mpl_toolkits.mplot3d import Axes3D
fig = plt.figure(figsize=(15,8))
ax1 = fig.add_subplot(121,projection='3d')
ax1.scatter(fraudulent['diffCorrectAmtAmt'],fraudulent['diffBalanceAmtOrig'],fraudulent['newBalanceOrig'],c='#8fb202',s=30)
ax2 = fig.add_subplot(122,projection='3d')
ax2.scatter(genuine['diffCorrectAmtAmt'],genuine['diffBalanceAmtOrig'],genuine['newBalanceOrig'],c='#00a2b3',s=30)
ax1.set_xlabel('Calc amt based on trans type vs Reported amt'); 
ax1.set_ylabel('Orig balances vs Reported amt'); 
ax1.set_zlabel('Orig balance after trans')
ax1.set_title('Fraudulent transactions', size = 20)
ax2.set_xlabel('Calc amt based on trans type vs Reported amt'); 
ax2.set_ylabel('Orig balances vs Reported amt'); 
ax2.set_zlabel('Orig balance after trans')
ax2.set_title('Genuine transactions',size=20)
plt.tight_layout()
plt.show()
```


![png](output_109_0.png)


While Originator's balance after transaction (z axis) equals to zero in most cases for fraud cases (the fraudster either transfers or cashes out the entire balance available), it varies greatly for genuine transactions. The number of cases where the new balance is not equal to zero somewhat corresponds to the difference in number of transfer (408) and cash-out (415) fraud cases from the pie-chart in EDA.  

Since the entire account balance is being defrauded, the reported amount equals to the difference between the old and the new balance for fraudulent transactions (y axis). 

## Tuning Best Models' Hyperparameters  

Both of the top two models had comparable results for their engineered scenarios with additional 7 features. When looking for the best hyperparameters in order to maximize performance of the model, the search will be conducted for both, an XGBoost model as well as for a Random Forest model. 


```python
from sklearn import pipeline
from sklearn.model_selection import cross_val_score
from sklearn.model_selection import StratifiedKFold
from sklearn.model_selection import GridSearchCV
from xgboost import XGBClassifier
from sklearn.ensemble import RandomForestClassifier
from tempfile import mkdtemp
cachedir = mkdtemp()

estimators = [('model', XGBClassifier())] 

# saving results to temporary cache to speed up the process
pipe = pipeline.Pipeline(estimators, memory = cachedir)

# passing HP as a list of dictionaries (the order doesn't matter here)
param_grid = [
# first model's HP
{'model': [XGBClassifier()], 
 'model__max_depth': [5,10],
 'model__learning_rate': [0.1,0.15,0.2],
 'model__n_estimators': [50,75,100],
 'model__n_jobs': [4]},
# second model's HP
{'model': [RandomForestClassifier()],
 'model__n_estimators': [50,75,100],
 'model__n_jobs': [4]}]
kfold = StratifiedKFold(n_splits=3, shuffle=True, random_state=38)
# specifying the n_jobs in the GridSearchCV to split the search into various branches and decrease the runtime for 
# finding the best combination of hyperparameters
grid = GridSearchCV(pipe, param_grid, cv=kfold,n_jobs=4,refit='f1',scoring=['balanced_accuracy','precision','recall',\
                                                                            'f1','average_precision'])
grid_fit = grid.fit(x_train_os_num, y_train_os_num)
```


```python
import pickle
# define file name and path to local folder
pkl_filename = '.../grid_search_fit_10pc_5features_no_validation.pkl'
```


```python
# save the model to local folder
pickle.dump(grid_fit, open(pkl_filename, 'wb'))
```


```python
# Load the model from file later
grid_fit = pickle.load(open(pkl_filename, 'rb'))
```


```python
grid_search_results = pd.DataFrame(grid_fit.cv_results_)
grid_search_results = grid_search_results.loc[:,['mean_fit_time','mean_score_time','param_model','param_model__learning_rate','param_model__max_depth','param_model__n_estimators','param_model__n_jobs','param_model__min_samples_leaf','mean_test_balanced_accuracy','rank_test_balanced_accuracy','mean_test_average_precision','rank_test_average_precision','mean_test_f1','rank_test_f1','mean_test_precision','rank_test_precision','mean_test_recall','rank_test_recall']]
grid_search_results.sort_values(['rank_test_f1','rank_test_average_precision','mean_fit_time'],ascending=True).head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>mean_fit_time</th>
      <th>mean_score_time</th>
      <th>param_model</th>
      <th>param_model__learning_rate</th>
      <th>param_model__max_depth</th>
      <th>param_model__n_estimators</th>
      <th>param_model__n_jobs</th>
      <th>param_model__min_samples_leaf</th>
      <th>mean_test_balanced_accuracy</th>
      <th>rank_test_balanced_accuracy</th>
      <th>mean_test_average_precision</th>
      <th>rank_test_average_precision</th>
      <th>mean_test_f1</th>
      <th>rank_test_f1</th>
      <th>mean_test_precision</th>
      <th>rank_test_precision</th>
      <th>mean_test_recall</th>
      <th>rank_test_recall</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>6</th>
      <td>85.300719</td>
      <td>5.669039</td>
      <td>XGBClassifier(base_score=0.5, booster='gbtree'...</td>
      <td>0.15</td>
      <td>5</td>
      <td>50</td>
      <td>4</td>
      <td>NaN</td>
      <td>0.997563</td>
      <td>1</td>
      <td>0.994456</td>
      <td>17</td>
      <td>0.995941</td>
      <td>1</td>
      <td>0.996764</td>
      <td>3</td>
      <td>0.995130</td>
      <td>1</td>
    </tr>
    <tr>
      <th>0</th>
      <td>95.472579</td>
      <td>6.717048</td>
      <td>XGBClassifier(base_score=0.5, booster='gbtree'...</td>
      <td>0.1</td>
      <td>5</td>
      <td>50</td>
      <td>4</td>
      <td>NaN</td>
      <td>0.997563</td>
      <td>1</td>
      <td>0.993234</td>
      <td>20</td>
      <td>0.995941</td>
      <td>1</td>
      <td>0.996764</td>
      <td>3</td>
      <td>0.995130</td>
      <td>1</td>
    </tr>
    <tr>
      <th>13</th>
      <td>109.869239</td>
      <td>6.405687</td>
      <td>XGBClassifier(base_score=0.5, booster='gbtree'...</td>
      <td>0.2</td>
      <td>5</td>
      <td>75</td>
      <td>4</td>
      <td>NaN</td>
      <td>0.996754</td>
      <td>3</td>
      <td>0.994891</td>
      <td>4</td>
      <td>0.995126</td>
      <td>3</td>
      <td>0.996764</td>
      <td>3</td>
      <td>0.993512</td>
      <td>3</td>
    </tr>
    <tr>
      <th>16</th>
      <td>111.553535</td>
      <td>6.016206</td>
      <td>XGBClassifier(base_score=0.5, booster='gbtree'...</td>
      <td>0.2</td>
      <td>10</td>
      <td>75</td>
      <td>4</td>
      <td>NaN</td>
      <td>0.996754</td>
      <td>3</td>
      <td>0.994837</td>
      <td>5</td>
      <td>0.995126</td>
      <td>3</td>
      <td>0.996764</td>
      <td>3</td>
      <td>0.993512</td>
      <td>3</td>
    </tr>
    <tr>
      <th>7</th>
      <td>116.371809</td>
      <td>5.906868</td>
      <td>XGBClassifier(base_score=0.5, booster='gbtree'...</td>
      <td>0.15</td>
      <td>5</td>
      <td>75</td>
      <td>4</td>
      <td>NaN</td>
      <td>0.996754</td>
      <td>3</td>
      <td>0.994835</td>
      <td>6</td>
      <td>0.995126</td>
      <td>3</td>
      <td>0.996764</td>
      <td>3</td>
      <td>0.993512</td>
      <td>3</td>
    </tr>
  </tbody>
</table>
</div>




```python
grid_search_results.to_csv('.../grid_search_results_10pct_AUPRC_5features_final.csv',sep=';')
```


```python
grid_fit.best_estimator_
```




    Pipeline(memory='C:\\Users\\MARKTK~1\\AppData\\Local\\Temp\\tmpo8o2t_g9',
         steps=[('model', XGBClassifier(base_score=0.5, booster='gbtree', colsample_bylevel=1,
           colsample_bytree=1, gamma=0, learning_rate=0.1, max_delta_step=0,
           max_depth=5, min_child_weight=1, missing=nan, n_estimators=50,
           n_jobs=4, nthread=None, objective='binary:logistic', random_state=0,
           reg_alpha=0, reg_lambda=1, scale_pos_weight=1, seed=None,
           silent=True, subsample=1))])




```python
best_model = grid_fit.best_estimator_
test_accuracy = round(metrics.balanced_accuracy_score(y_test_os_num,best_model.predict(x_test_os_num))*100,2)
test_precision = round(metrics.precision_score(y_test_os_num,best_model.predict(x_test_os_num))*100,2)
test_recall = round(metrics.recall_score(y_test_os_num,best_model.predict(x_test_os_num))*100,2)
test_F1_score = round(metrics.f1_score(y_test_os_num,best_model.predict(x_test_os_num))*100,2)
test_AUPRC = round(metrics.average_precision_score(y_test_os_num,best_model.predict(x_test_os_num))*100,2)
print(f'Test Accuracy score: {test_accuracy} %')
print(f'Test Precision score: {test_precision} %')
print(f'Test Recall score: {test_recall} %')
print(f'Test F1 score: {test_F1_score} %')
print(f'Test AUPRC: {test_AUPRC} %')
print()
print(f'Confusion matrix:')
print(metrics.confusion_matrix(y_test_os_num, best_model.predict(x_test_os_num)))
```

    Test Accuracy score: 100.0 %
    Test Precision score: 99.03 %
    Test Recall score: 100.0 %
    Test F1 score: 99.51 %
    Test AUPRC: 99.03 %
    
    Confusion matrix:
    [[158859      2]
     [     0    205]]
    

The cross-validation grid search shows that the best hyperparameters were already used for train purposes because the predictions haven't improved.  

## AUPRC


```python
from sklearn.utils.fixes import signature
proba_train_RF = RF_model_os_num.predict_proba(x_train_os_num) 
proba_test_RF = RF_model_os_num.predict_proba(x_test_os_num) 
precision_train, recall_train, _ = metrics.precision_recall_curve(y_train_os_num, proba_train_RF[:, 1]) 
precision_test, recall_test, _ = metrics.precision_recall_curve(y_test_os_num, proba_test_RF[:, 1]) 

step_kwargs = ({'step': 'post'}
               if 'step' in signature(plt.fill_between).parameters
               else {})
fig2 = plt.step(recall_train, precision_train, color='#8fb202', alpha=0.8,where='post')
fig2 = plt.fill_between(recall_train, precision_train, alpha=0.7, color='#8fb202',step='post')
fig1 = plt.step(recall_test, precision_test, color='#00a2b3', alpha=0.8,where='post')
fig1 = plt.fill_between(recall_test, precision_test, alpha=0.7, color='#00a2b3',step='post')

plt.xlabel('Recall')
plt.ylabel('Precision')
plt.ylim([0.95, 1.01])
plt.xlim([0.95, 1.01])
plt.legend((fig1,fig2),('Test','Train'))
plt.title('Area under Precision-Recall curve - Random Forest');
```


![png](output_123_0.png)



```python
proba_train_XGB = XGB_model_os_num.predict_proba(x_train_os_num) 
proba_test_XGB = XGB_model_os_num.predict_proba(x_test_os_num) 
precision_train, recall_train, _ = metrics.precision_recall_curve(y_train_os_num, proba_train_XGB[:, 1]) 
precision_test, recall_test, _ = metrics.precision_recall_curve(y_test_os_num, proba_test_XGB[:, 1]) 

step_kwargs = ({'step': 'post'}
               if 'step' in signature(plt.fill_between).parameters
               else {})
fig2 = plt.step(recall_train, precision_train, color='#8fb202', alpha=0.8,where='post')
fig2 = plt.fill_between(recall_train, precision_train, alpha=0.7, color='#8fb202',step='post')
fig1 = plt.step(recall_test, precision_test, color='#00a2b3', alpha=0.8,where='post')
fig1 = plt.fill_between(recall_test, precision_test, alpha=0.7, color='#00a2b3',step='post')

plt.xlabel('Recall')
plt.ylabel('Precision')
plt.ylim([0.95, 1.01])
plt.xlim([0.95, 1.01])
plt.legend((fig1,fig2),('Test','Train'))
plt.title('Area under Precision-Recall curve - XGBoost');
```


![png](output_124_0.png)


The Area under the Precision-Recall Curve (AUPRC) has an intention to show the trade-off needed when trying to maximize particular metric.  

## Conclusion

The best two models for detecting and predicting fraudulent transactions proved to be Random Forest and XGBoost with a Decision Tree as a base model. While reaching close-to-100% levels of F1 score, Precision, Recall and AUPRC, the interpretability of the model is not so straight-forward. The next steps would be to use ideally SHAP package that consistently evaluates the feature importance while not depending on the order in which the features were added/evaluated or how deep in the decision tree are they positioned. The interpretability of the model is one of the key aspects of model validation framework whose intention is, among other, to check whether a model being used by financial institution or a provider of behavioral solution services is compliant with anti-discrimination laws.  
